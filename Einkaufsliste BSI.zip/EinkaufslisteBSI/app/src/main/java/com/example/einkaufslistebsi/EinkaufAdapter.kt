package com.example.einkaufslistebsi

import EinkaufArtikel
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter für die RecyclerView.
 * Verbindet die Daten (EinkaufArtikel) mit der Darstellung in der Liste.
 */
class EinkaufAdapter(
    private val items: MutableList<EinkaufArtikel>,
    private val onItemClick: (Int) -> Unit // Callback-Funktion für Klicks
) : RecyclerView.Adapter<EinkaufAdapter.EinkaufViewHolder>() {

    /**
     * ViewHolder verwaltet ein einzelnes Listenelement.
     */
    class EinkaufViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewItem: TextView = itemView.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EinkaufViewHolder {
        // Einfaches Standardlayout für die Einträfe in der Liste
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return EinkaufViewHolder(view)
    }

    override fun onBindViewHolder(holder: EinkaufViewHolder, position: Int) {
        val item = items[position]
        holder.textViewItem.text = item.name

        holder.textViewItem.setTextColor(Color.parseColor("#212121"))

        // Artikel wird entfernt, wenn man auf den Eintrag klickt
        holder.itemView.setOnClickListener {
            onItemClick(position)
        }
    }

    override fun getItemCount(): Int = items.size
}
