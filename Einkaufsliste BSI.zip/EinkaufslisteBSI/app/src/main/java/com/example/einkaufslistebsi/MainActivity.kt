package com.example.einkaufslistebsi

import EinkaufArtikel
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    // Datenquelle: Liste aller Artikel, die aktuell auf der Einkaufsliste stehen
    private val einkaufsliste = mutableListOf<EinkaufArtikel>()

    // Adapter für die RecyclerView – verbindet die Daten mit der Anzeige
    private lateinit var adapter: EinkaufAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ---------------------------------------------
        // UI-Elemente: Steuerelemente, für den Benutzer. Darunter fallen z.B. EditText, Button und RecyclerView
        // ---------------------------------------------

        // Eingabefeld, in das der Nutzer einen Artikel wie "Milch", "Brot" etc. eingeben kann
        val editTextItem = findViewById<EditText>(R.id.editTextItem)

        // Button, mit dem ein neuer Artikel zur Einkaufslste hinzugefügt werden kann
        val buttonAdd = findViewById<Button>(R.id.buttonAdd)

        // RecyclerView: Liste zur Anzeige vieler Datenobjekte, ist am effizientesten für lange Listen
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        // ---------------------------------------------
        // RecyclerView vorbereiten: Layout und Adapter setzen
        // ---------------------------------------------

        // Adapter bekommt die Liste und einen Klick-Handler
        adapter = EinkaufAdapter(einkaufsliste) { position ->
            // Artikel wird entfernt, wenn man darauf klickt
            einkaufsliste.removeAt(position)
            adapter.notifyItemRemoved(position)
        }

        // LayoutManager bestimmt, wie die Liste angezeigt wird (z.B. vertikal untereinander)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // RecyclerView mit Adapter verbinden
        recyclerView.adapter = adapter

        // ---------------------------------------------
        // Logik für den Hinzufügen-Button
        // ---------------------------------------------

        buttonAdd.setOnClickListener {
            val text = editTextItem.text.toString().trim()
            if (text.isNotEmpty()) {
                // Artikel zur Liste hinzufügen
                einkaufsliste.add(EinkaufArtikel(text))

                // RecyclerView über neue Daten informieren
                adapter.notifyItemInserted(einkaufsliste.size - 1)

                // Eingabefeld leeren
                editTextItem.text.clear()
            }
        }
    }
}



