// Einfaches Datenmodell für Elemente in einer Liste (z.B. "Milch", "Brot", "Apfel")
data class EinkaufArtikel(val name: String)
